function u=GetRobotControl(k)
global nSteps;
%u=[0;0.25;0.3*pi*sin(3*pi*k/nSteps)];
u=[0;0.15;0.2*pi/180];
end